# Bike Share Problem: <"Dead and Live" Bike Stations>
# File: BikeShare(1).py
# Date: 24 April 2019
# By: Rohan Lotlikar
# 00305-05294
# Section: 18
# Team: Team 08
#
# ELECTRONIC SIGNATURE
# Rohan T. Lotlikar
#
# The electronic signature above indicates that the program
# submitted for evaluation is my individual work. I have
# a general understanding of all aspects of its development
# and execution.
#
#This program outputs information on bike share locations that have a net gain or net less.

import pandas as pd
import numpy as np
import glob


files = sorted(glob.glob('2017*.csv'))

def findDeadStations(endStart):
    end = endStart["End station number"].value_counts();
    start = endStart["Start station number"].value_counts();
    diff = end - start;
    deadStations = diff[diff > np.std(diff)];
    return deadStations.index;
def findLiveStations(endStart):
    end = endStart["End station number"].value_counts();
    start = endStart["Start station number"].value_counts();
    diff = start - end;
    deadStations = diff[diff > np.std(diff)];
    return deadStations.index;
def findNightStations(endStart):
    endData = endStart["End date"];
    nights = [];
    count = -1;
    for data in endData:
        count = count + 1;
        dataSplit = data.split(' ');
        times = dataSplit[1].split(':');
        if int(times[0]) > 20:
            nights.append(count);
    night = endStart["End station"].loc[nights].value_counts();
    startData = endStart["Start date"];
    days = [];
    count2 = -1;
    for data in startData:
        count2 = count2 + 1;
        dataSplit = data.split(' ');
        times = dataSplit[1].split(':');
        if int(times[0]) < 9:
            days.append(count2);
    day = endStart["Start station"].loc[days].value_counts();
    nightDay = night - day;
    nightStations = night[nightDay > np.std(nightDay)];
    dayNight = day - night;
    dayStations = day[dayNight > np.std(dayNight)];
    return nightStations,dayStations;
fs = [];

for f in files:
    df = pd.read_csv(f);
    fs.append(df);
df = pd.concat(fs,axis =0,ignore_index=True);

endStart = df[["Start station number","End station number","Start station","End station","Start date","End date"]];
deadStations = findDeadStations(endStart);
liveStations = findLiveStations(endStart);

print("The following stations are dead stations:");
print(endStart["End station"].loc[deadStations]);
print("The following stations are live stations:");
print(endStart["Start station"].loc[liveStations]);

dayNightStations = findNightStations(endStart);
nightStations = dayNightStations[0];
dayStations = dayNightStations[1];

print("The following stations are night stations.");
print(nightStations);
print("The following stations are day stations.");
print(dayStations);




    


